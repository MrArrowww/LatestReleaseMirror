Skirk portable data lives here. Imported profiles, configs, and logs stay beside Skirk.exe.
